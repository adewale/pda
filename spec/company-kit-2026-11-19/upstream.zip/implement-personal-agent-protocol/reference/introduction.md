# Introduction

## What is Personal Agent Protocol?

Personal Agent Protocol (Poppy for short) is an open protocol for how personal agents and companies work together. A company uses it to declare how personal agents can interact with it. A personal agent uses it to sign in safely and get access to a person's account, limited to what that person and the company agree to.

The goal is for the protocol to cover everything a company and a personal agent can do together, so each side implements it once and works with every other side that supports it.

## Why does it exist?

Personal agents are already here, and people like using them. They hand off everyday tasks, and many of those tasks end at a company. Companies are already seeing this traffic. Some block it, and others are deciding whether to.

Today it is all or nothing. Either the agent passes as the user, signing in with their password and clicking through pages built for people, or the company blocks it and it can't do anything. Neither works well. The user can't limit what the agent does once it's in, and the company can't tell an agent from a person or offer it a better path.

There need to be more points between those two extremes, so that companies and users can choose how agents work with them. An airline might let any agent search flights, let signed-in agents see the user's trips, and require the user's approval before buying a ticket. A user might let an agent see their trips but not change them.

As agents take on more of what people do online, the cost of all or nothing grows: companies spend more effort detecting agents, and agents spend more effort evading detection. Personal Agent Protocol gives both sides a way to work together, with more choice and control.

## Principles

- **Built on existing standards.** Personal Agent Protocol uses OAuth, JWTs, HTTPS, OpenAPI, and MCP wherever they fit, so teams can implement it with libraries and tools that already exist. It defines something new only where no standard covers the need.
- **Controls, not policy.** The protocol offers a range of options, and each side chooses what fits. A company decides whether agents can work anonymously or must sign the user in, which personal agents to allow, which channels to offer, and how much access to grant. A user decides how to sign in and what the agent can see and do in their account.
- **Secure and private.** We think Personal Agent Protocol can become part of the foundation of the internet, so it has to be trustworthy. A personal agent always identifies itself, but until the person signs in, the company knows them only by an ID that contains no personal information. The ID stays the same over time, so the company can recognize a returning user, but it is different at every company. Companies can choose which sign-in options meet their security needs, and access is limited to what was granted and can be revoked.
- **Progressive adoption.** A company can start with only a website, only APIs, or only an agent, and add more over time, without rebuilding its existing systems.
- **Extensible.** Discovery, identity, APIs, and conversations are building blocks that companies and industries can extend. Extensions already add approval of exact terms before an action, links and disclosures in messages, and checkout through UCP.

## Roadmap

There are several areas we want to invest more in, roughly in order of priority below. To join a discussion or raise something that isn't here, [send feedback](#feedback).

### Signed approvals

**Goal:** For actions that are hard to undo, such as a cancellation or a new payment method, a Company can verify that the User approved the exact terms, instead of trusting the Personal Agent's word.

**Where it stands:** In the [Operations extension](https://personalagentprotocol.org/docs/1.0/extensions/operations), an approval covers one revision of an operation's exact terms. It is user approved, when the Personal Agent asks the User, or agent approved, when the Personal Agent approves on the User's instruction, and can carry a reference to the Personal Agent's own record of it. Either way the Company relies on the Personal Agent ([Operations 8.1](https://personalagentprotocol.org/docs/1.0/extensions/operations#approval-proof)), so a Company that wants to see the User approve an action doesn't offer it through operations yet. A signature from the User's device would add a third kind, signed user approval, as one more member of a user approval. Mandates, where the User signs once for a class of actions with limits, such as transfers of up to $50 a week, would build on it. The proposals take three approaches: the User approves on the Company's own page or in its app, the User's device signs the terms with a key the User registered with the Company, or a third party attests to the approval. Some actions also need the account holder, not just anyone on the account, to approve.

**Issues:** [roadmap: approvals](https://github.com/personal-agent-protocol/personal-agent-protocol/issues?q=is%3Aissue%20label%3A%22roadmap%3A%20approvals%22)

### Payments

**Goal:** A Personal Agent can pay a Company in a way that is tied to what the User approved, using existing payment and checkout protocols rather than replacing them.

**Where it stands:** The [UCP extension](https://personalagentprotocol.org/docs/1.0/extensions/ucp) lets a Company that speaks the Universal Commerce Protocol handle carts, checkout, and payment there, while this protocol finds the Company and signs the User in. How payment works with the Operations extension is open. Proposals cover a Payment Provider that issues a credential bound to one approved operation, financing offers, evidence that a payment settled for an approved revision, and strong customer authentication for EU payments.

**Issues:** [roadmap: payments](https://github.com/personal-agent-protocol/personal-agent-protocol/issues?q=is%3Aissue%20label%3A%22roadmap%3A%20payments%22)

### Push notifications

**Goal:** A Company can tell the Personal Agent that something happened when no request is open, such as an order shipping, a flight being cancelled, or a reply arriving hours later.

**Where it stands:** Not started in the spec. Today a Personal Agent only learns about a change by checking again. The issues collect use cases and design rules.

**Issues:** [roadmap: push notifications](https://github.com/personal-agent-protocol/personal-agent-protocol/issues?q=is%3Aissue%20label%3A%22roadmap%3A%20push%20notifications%22)

### Delegated sign-in

**Goal:** A User can sign in at a Company with an account they already have at an identity provider, and the Company accepts that sign-in for the Personal Agent, so the User doesn't sign in again at each Company.

**Where it stands:** Not started in the spec. Today the User signs in at each Company's own authorization server ([4.2](https://personalagentprotocol.org/docs/1.0/spec#direct-sign-in), [4.3](https://personalagentprotocol.org/docs/1.0/spec#device-sign-in)). A Company's sign-in page can already offer an identity provider, but the User still signs in once per Company, and the Company can't tell the Personal Agent which identity providers it accepts.

### Attachments

**Goal:** Company messages and operation results can carry more than text and data, such as receipts, return labels, product images, and forms for the User to fill in, with enough information for the Personal Agent to fetch, show, and pass them on.

**Where it stands:** Not started in the spec. A Company can put a URL in a message's `data`, but nothing says how to fetch it, who can open it, or when it stops working.

**Issues:** [roadmap: attachments](https://github.com/personal-agent-protocol/personal-agent-protocol/issues?q=is%3Aissue%20label%3A%22roadmap%3A%20attachments%22)

### Self-hosted personal agents

**Goal:** A Personal Agent that runs on the User's own devices, such as a desktop app, a phone app, or a browser extension, can identify itself and sign in without a server that learns which Companies each User works with, and can act in the browser where the User is already signed in.

**Where it stands:** Desktop apps can receive sign-in responses on a loopback address. A device can sign its own requests with a delegated key, and the agent's server can sign the delegation without seeing it. Browser extensions, and acting in the User's own signed-in browser, are still open: today a Personal Agent joins only a browser it controls.

**Issues:** [roadmap: self-hosted agents](https://github.com/personal-agent-protocol/personal-agent-protocol/issues?q=is%3Aissue%20label%3A%22roadmap%3A%20self-hosted%20agents%22)

### Drop Mediated Sign-In

**Goal:** Remove the [Mediated Sign-In extension](https://personalagentprotocol.org/docs/1.0/extensions/mediated-sign-in), so Users sign in on the Company's own page and Personal Agents never handle a User's password or one-time code.

**Where it stands:** Mediated Sign-In, where the Personal Agent signs in with the User's credentials, is transitional. The protocol plans to remove it on March 17, 2027, and Direct Sign-In is now the preferred sign-in type. Still open: whether Direct Sign-In should be the one required type, and what to say about agents typing a password into a Company's website, which happens outside the protocol.

**Issues:** [roadmap: mediated sign-in](https://github.com/personal-agent-protocol/personal-agent-protocol/issues?q=is%3Aissue%20label%3A%22roadmap%3A%20mediated%20sign-in%22)

## Providing feedback

Anyone can implement the protocol, as a personal agent or a company, and feedback is welcome from anyone, whether or not you're a design partner.

Give feedback by [opening an issue](https://github.com/personal-agent-protocol/personal-agent-protocol/issues/new) on GitHub, or by commenting on an existing issue for a [roadmap](#open-topics) topic. Feedback you send is licensed under the [contribution terms](https://personalagentprotocol.org/license/contributions).

If you'd like an agent to review the docs, give it the [implementation kit](https://personalagentprotocol.org/kit/company), which includes all the docs. Paste the agent's review into your issue.

## Design partners

The spec's authors are working through implementations with several of these partners. Partners that have agreed to be listed, in alphabetical order.

- 1Password
- Adyen
- Affirm
- Aflac
- Agoda
- Aircall
- Akoya
- Atomic
- Aviva
- Banco Sabadell
- Bank of America
- BBVA
- Braze
- Browserbase
- Checkout.com
- Chime
- Cigna
- Cisco
- Cloudflare
- Comcast
- Cover Genius
- Creditas
- Crunch Fitness
- Cue
- Delta Air Lines
- Descope
- DIRECTV
- EarnIn
- ElevenLabs
- Five9
- FOX
- Freshworks
- Fullstory
- Gap Inc.
- GEICO
- Gen Digital
- Genesys
- Global Payments
- GoFundMe
- GoodRx
- Guardian
- HealthEx
- HelloFresh
- Hertz
- Hyatt
- Infoblox
- Insurify
- Intuit
- Kernel
- Kin Insurance
- Klaviyo
- Lemonade
- Liberty Global
- Liberty Mutual
- Manus
- Mastercard
- Mercury
- Meta
- Navy Federal Credit Union
- Neptune Flood
- NiCE
- Nordstrom
- Notion
- Okta
- OneSignal
- OpenAI
- Ora
- PayPal/Venmo
- Persona
- Pindrop
- Ping Identity
- Plaid
- Profound
- Prosus
- Remitly
- Rocket
- Runlayer
- Salesforce (Fin, Commerce Cloud, and Agentforce)
- Shopify
- Sierra
- SiriusXM
- Socure
- SoFi
- Stripe
- Symphony
- Synchrony
- Target
- The Knot
- The Zebra
- Travelers
- Turkish Airlines
- Twilio
- United Airlines
- Visa
- Walmart
- Wayfair
- Wells Fargo
- Wix
- WorkOS
- Zapier
- Zendesk
- Zoom

---

Licensed under the [Apache License 2.0](https://personalagentprotocol.org/license).
