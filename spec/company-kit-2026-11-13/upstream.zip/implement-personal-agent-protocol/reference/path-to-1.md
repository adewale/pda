# Path to 1.0

**Current status**, updated November 11, 2026

Build against the [1.0 draft](https://personalagentprotocol.org/docs/1.0/spec), the latest version. It's [version 0.4](https://personalagentprotocol.org/docs/0.4/spec) with fixes for problems found while implementing it, and the [changelog](https://personalagentprotocol.org/docs/changelog#v1-0) lists each fix. We're not adding new features until 1.0 is published.

## How we get there

- **Anyone can implement it.** Build against it, as a personal agent or a company, and [send us feedback](#feedback) on what you run into.
- **We're implementing it with design partners.** The spec's authors are working through implementations with several of the [design partners](#partners).
- **The spec changes based on what we learn.** From the release candidate on, changes before 1.0 are fixes, made in a draft 1.0, not new features. A fix can still break compatibility with earlier versions.

## Providing feedback

Feedback is welcome from anyone, whether or not you're a partner.

Give feedback by [opening an issue](https://github.com/personal-agent-protocol/personal-agent-protocol/issues/new) on GitHub, or by commenting on an existing issue for a [roadmap](https://personalagentprotocol.org/docs/roadmap) topic. Feedback you send is licensed under the [contribution terms](https://personalagentprotocol.org/license/contributions).

Two tools can help you write it:

**Review with an agent.** If you'd like an agent to review the docs, give it the [implementation kit](https://personalagentprotocol.org/kit/company), which includes all the docs. Paste the agent's review into your issue.

**Use the site's inline comments.** You can comment on any text on this site, then export your comments to share them. Enable site commenting, then select text to comment on it. To export, use the … button next to Comments, and paste or attach the export in your issue.

## Roadmap

The [roadmap](https://personalagentprotocol.org/docs/roadmap) lists the areas we expect to work on before 1.0, including the ones the spec doesn't cover yet, such as payments, push notifications, and attachments.

## Design partners

Partners that have agreed to be listed, in alphabetical order.

### Personal agents

- Instinct
- Meta
- OpenAI

### Companies

- Bank of America
- BBVA
- Chime
- Cigna
- Comcast
- DIRECTV
- FOX
- Gap Inc.
- GEICO
- Hertz
- Insurify
- Liberty Mutual
- Nordstrom
- PayPal/Venmo
- Rocket
- SiriusXM
- Synchrony
- Target
- United Airlines
- Walmart
- Wells Fargo

### Technology providers

- 1Password
- Adyen
- Atomic
- Cloudflare
- ElevenLabs
- Genesys
- Klaviyo
- Mastercard
- NiCE
- Notion
- Okta
- OneSignal
- Plaid
- Shopify
- Sierra
- Stripe
- Visa
- Zapier
- Zendesk

---

Licensed under the [Apache License 2.0](https://personalagentprotocol.org/license).
