# Pattern: serving poppy.json

`poppy.json` is served at `https://{domain}/.well-known/poppy.json` on the Company's own domain
([section 3](https://personalagentprotocol.org/docs/0.3/spec#discovery)). The document speaks for the
host that serves it at `/.well-known/poppy.json` after any redirects, so a redirect must end at that
path, and `organization.domain` must be that host
([3.1](https://personalagentprotocol.org/docs/0.3/spec#fields)).

## Options

**A static file in the website.** Deploy `poppy.json` with the site, or from the CDN or edge that
serves it.

- Fits: most Companies. The content changes only when an interface or extension is added.
- Needs: a way to serve a path under `/.well-known/` with `Content-Type: application/json`.
- Watch for: caching. Personal Agents cache by HTTP caching headers
  ([guides](https://personalagentprotocol.org/docs/0.3/guides#both-fetching)), so use a short
  enough lifetime that a change takes effect when you need it to.

**Generated per environment.** Build the file, and the domain's protected resource metadata, from
configuration, so staging and production list their own endpoints and issuer.

- Fits: Companies with several environments or several country domains.
- Watch for: every domain that names an issuer must appear, as exactly `https://{domain}` with no
  path or trailing slash, in that issuer's `protected_resources`
  ([3.2](https://personalagentprotocol.org/docs/0.3/spec#oauth-server)).

**Served by a provider on the Company's domain.** A provider that runs part of the Company's
Poppy support can serve the document, through a reverse proxy or a hostname the Company points at
the provider.

- Fits: Companies that use a provider for the token endpoint or the Company Agent.
- Watch for: a redirect from the Company's domain to the provider's domain doesn't work. After the
  redirect, the document would speak for the provider's host, not the Company.

## What to watch for

- Optionally publish `skill_index` for Personal Agents performing the User's tasks at this
  Company ([9.4](https://personalagentprotocol.org/docs/0.3/spec#agent-context)). Embed the complete Agent
  Skills discovery `0.2.0` index with `$schema` and `skills`; every entry has `name`, `description`,
  `type`, `url`, and a `sha256:` digest of its raw artifact bytes. Follow the pinned discovery
  draft's distribution requirements. Full HTTPS URLs may point to a CDN or another domain.
  Relative references resolve against the final `poppy.json` URL, so use absolute URLs to reuse
  entries in a separate well-known index. Include workflows for Personal Agents here, not the
  developer skill used to implement Poppy. Skills grant no account access or User approval.
- Redirects are allowed, but only to HTTPS, and the last URL's path must be exactly
  `/.well-known/poppy.json` with no query (section 3). If `example.com` redirects to
  `www.example.com`, `organization.domain` is `www.example.com`. Domains are compared ignoring case
  and nothing else (3.1).
- A Company that offers sign-in needs an issuer, found from the domain's protected resource
  metadata at `/.well-known/oauth-protected-resource`
  ([3.2](https://personalagentprotocol.org/docs/0.3/spec#oauth-server)). Without one, return 404 or
  publish valid metadata with no authorization servers. Session JWTs then name
  `https://{organization.domain}` with a lowercase host and no trailing slash. Discovery errors
  must not silently choose this fallback.
- `auth.issuer` is required when that metadata lists more than one authorization server. With one,
  it's optional, and if present it must name that server (3.1).
- `auth.disabled: true` tells Personal Agents not to sign in, for a Company whose issuer serves
  other clients but that isn't ready for Personal Agents (3.2). It can't be combined with Mediated
  Sign-In or `access: signed_in`.
- Domains that share an issuer are one Company and must select that issuer and give scopes the
  same authorization meaning ([3.2](https://personalagentprotocol.org/docs/0.3/spec#oauth-server)).
  Matching scope descriptions and hints are recommended; domains can expose different scopes and
  capabilities.
- List interfaces and extensions only when they work. Add each as it ships. Direct and Device
  Sign-In come from the issuer's `grant_types_supported` (3.2), not `poppy.json`.
- Check before deploying: `node <skill-dir>/validate/index.ts check --file ./poppy.json`.
